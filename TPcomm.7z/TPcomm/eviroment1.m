%%TP communication sans fil

M = 2;
n = 6